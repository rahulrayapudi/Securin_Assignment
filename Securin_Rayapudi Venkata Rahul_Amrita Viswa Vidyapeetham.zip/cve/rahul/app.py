from flask import Flask, render_template, request, jsonify
import json
from pymongo import MongoClient
from datetime import datetime


app = Flask(__name__)


uri = "mongodb+srv://rahul:rahuldb@cluster0.teorlul.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
client = MongoClient(uri)

db = client["securin"]
collection = db["CVE"]

app = Flask(__name__)

@app.route('/cves/list')
def cves_list():
    startPage = request.args.get('startPage', default=1, type=int)
    resultsPerPage = request.args.get('resultsPerPage', default=10, type=int)

    start_index = (startPage - 1) * resultsPerPage

    paginated_data = collection.find({},{"id":1,"sourceIdentifier":1,"published":1,"lastModified":1,"vulnStatus":1,"_id":0}).skip(start_index).limit(resultsPerPage)
    return render_template('table.html', cves=paginated_data, total_records=collection.countDocuments(), resultsPerPage=resultsPerPage, startPage=startPage)

@app.route('/cves/<cve_name>')
def get_cve(cve_name):
    cve = collection.find_one({"id": cve_name})
    return render_template('cve.html', cve = cve)

if __name__ == '__main__':
    app.run(debug=True)

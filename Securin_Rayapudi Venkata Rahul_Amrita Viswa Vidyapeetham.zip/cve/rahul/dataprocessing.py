import json

def process_json(input_file, output_file):
    try:
        with open(input_file, 'r') as f:
            data = json.load(f)

        db = []

        for item in data["vulnerabilities"]:
                db.append(item["cve"])

        json_data = json.dumps(db, indent=4)

        with open(output_file, "w") as json_file:
            json_file.write(json_data)

    except FileNotFoundError:
        print("Input JSON file not found.")
    except Exception as e:
        print("An error occurred:", e)

process_json("db.json", "formatdb.json")
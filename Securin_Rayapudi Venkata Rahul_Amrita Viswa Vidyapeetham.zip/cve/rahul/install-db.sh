curl https://services.nvd.nist.gov/rest/json/cves/2.0 -o db.json
